<?php
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
    require_once ($_SERVER['DOCUMENT_ROOT'] . '/errordocuments/404.php');
    exit();
}

require($_SERVER['DOCUMENT_ROOT'] . '/../include/authenticate.php');

if (!$_SESSION['logged_in']) {
    include ($_SERVER['DOCUMENT_ROOT'] . '/errordocuments/403forbidden.php');
    exit();
}

$_SESSION['LAST_ACTIVITY'] = time();
require_once ($_SERVER['DOCUMENT_ROOT'] . '/../include/header/_header_header_text.php');
include ($_SERVER['DOCUMENT_ROOT'] . '/../include/header/_header_include_base.php');
require_once ($_SERVER['DOCUMENT_ROOT'] . '/../include/class/class.encrypt.php');
$protocol = connectionType();

//////////////////////////////////////////////////////////////////////////////////////////////
$male = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD//gA8Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2NjIpLCBxdWFsaXR5ID0gMTAwCv/bAEMAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/bAEMBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/AABEIADIAMgMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APpg/wDB7V+xcfFkVkP2PP2nB4INyI5fEja58LB4mjtC+Dcp4PXxG+mySqnz/Zj41jBPy+eCAa/qP/Yf/b2/Zd/4KIfBiy+On7K/xHs/HXhGS6XTPEGlzQvpPjDwN4iECXM3hnxv4YumN9oOsxQyLNGkolsdQtWS+0q9v7F47lv8Niv0M/4Js/t2ftvfsNfHu21v9hbxPqVp8Uvi3BZfC3/hA4/D9v400f4i3XiDUrW38PaPc+C79ZbDWNcg1uS2bw3dCIX9jezSRW0wgvLyC4AP9uL5efxz0x78e23sPz5peBz6cevA4/Lvgc/jmvwG/wCCNa/8F3/EF74q8f8A/BV/Xfgnofw317wsY/Afwo0zwz4bsfjbovi5tR0ye21fW734eIngzR/DQ0ddWtbrRdS1TXvEE+ozWbmDR47WU3nq/wDwVW+B3/BZ/wCM194Gtv8Agl1+1j+zr+zZ4R0/w7dr8Qbf4n+HLu48e+IvFUmo3TW8+ieJZ/hX8XNFstAi0g2MKWKaJo2pR6it7cy6ndwTW1vagH4nf8Hev/BU3xV+z18KPhz+wJ8CfGureEviV8d9Ob4g/GvXfDOoz6drOjfBS1utS0bRfB6ajYzw3mnSfEXxLZ3dxqPkSR3D+HfC1xYTAWPiAiX/AD5fgx+1l+1B+zpPdXHwF/aF+M/wde+Wdb1Phx8SPFvhC3vBcgidrq00TVbO1uJJATullheTkkOCTXsn/BSXXv2p9V/bU+O+g/tofGW3+PX7Rfw18X3Xwq+IPxH07Vf7Y0PUtQ8AAaB9g8O3a6B4Wi/sXSWtpLK2jg8O6TH5sVxJ9l8yR5ZfhmgD7Cl/4KFft5TyyTS/tn/tSvLNI8srn48/E7LySMXdjjxMBlmJJwAMmivj2igAr6S/Y3+LPhH4C/tZ/s1fGzx9o93r/gn4TfHP4XfETxZo1gzLfah4f8IeMtH1zVYLIq8Ra7+x2Ur20fmRiWZUjLoHLD5tr9Av+CU3wWH7Q/8AwUg/Yt+Dsk3heO28Y/tA+AU1CLxnawX3hvUdK0LVE8Tavomo2F14c8WWWoNr+maNd6JY6fqPh+/0y+1HULS01M2dhNc31sAf7Yvg/wAWeG/H3hTwx458HaxZeIfCXjLQNH8UeGdd02YTWGs6Br9hb6po+qWUwXElrfWF1b3ML4y0cq5AOQNbUdQ0/SNPv9W1W9ttO0zS7O51HUdQvZ47aysbCyhe5vLy7uZmSK3tbW2iknnnlZY4okeR2VVJo0vS9O0TTrDRtG06y0nSNKs7bTtL0vTLSKw07TdPs4UtrOwsLK0jhtrSztLeKKC2treKOCCGNIokRFChNV0rT9d0zUdF1mwtNV0jV7G70vVdL1C2S8sNS03UIJLW+sL60nSSC6s7u1lkt7m3mR4p4ZHjkV1YigD/AA//APgpN8afhf8AtF/t8/tc/HL4LaK+g/Cz4ofHfx/4t8FWUj3DyXWj6lrU7LrrrcyyzW7+KLlLjxK1kXCWB1Y2UMcMNvHEnxHX9Jn/AAdL/sgfA/8AY8/4KR6Z4W/Z98HfDn4ZfD3x78CPAfjm3+Gfw502y0Ow8KamdS8R+HdTnv8ARNP0qxt7GbxBdaI+rQSyXup3N3HI8jtZWyWlqP5s6ACiiigD+33/AIM2/wDgn58NPjX49/aW/bM+MfgHwt8QdH+E0OhfBj4V6V4z0HTvEWi6f478TQW/ivxj4nttN1a1urBtd0PwxDoGlafdvG0lja+LNReJRNNDND/fN4c/ZB/ZR8H/ABGsvi/4R/Zp+A3hX4qabFcxaf8AEPw38JfAmheM7JbyJ7e7Np4i0vQbTVLeW4tpZbWeaK6E0ltLJbPKYXZW/ny/4IZ/sl/Eb/gj1+1N+1H/AMEyPiNd3vjT4WfGtX/a3/ZJ+OCWC2OleP8ARvDMHhn4b/FHwP4hgjU2+k/E7wxYz+BNS1PQ7e4uLa60i3udfsDHZXUcK/1L5x+PHGTzgYzken48AgckUALnoOf0BGO556HB5HHbvRxjqevXjOePQc8cjjp7YpOc4GQAQOvbA9eOw79+hyaXPoDj+fPJHc9fTB7e4B+fn7V//BK7/gnx+3J4/wDD/wAUv2rv2XvAfxn+IHhbw3F4Q0TxV4gu/Fen6hb+GbfUb/VbbRrj/hGvEWiW2qWVpqGqajdWkeqwXrWr3tytu0aSuh/iY/4Owf8AglZ+xD+xB8Ev2U/i/wDsi/ADw/8ABDWvGPxZ8V/DXxvD4P1HxRPpHiKwbwe3iTQDdaVrOuavY22pWNzpGpLBd2EFpdXkN1PHePcLb24i/wBGjIAySQOpY8DA656kY9zg8/wgCvwN8Afsgt/wUy/bVtf+Cgn7VWktrn7Ln7O+qal4S/4J3/ADXonk8O+I7rSdSig8S/tf+PtFkAttWu/G2vafcD4QaTqCXtgfAmneG/F08AnvdOFAH+bN4a/4IY/8Fa/F3hzQPFegfsJfHa80LxPouleIdFu5PDtvZSXWk61Ywalp1zJZX19bX1o89ncwyva3lvb3VuzGK4himR41K/2ic7flAwF4A+YYA4AwCAMDsAMelFAHmHjzTNNufG3wX1O50+xuNS0vxp4iXTNQntLeW+05b74ZeOIb0WF3JG09mLyFEiuhbyRi4iRY5t6qAPUl6j6f0WiigBx6fUjP5gfy4owPQflRRQBDKiSwSxyIskciMkkbqHSRHQK6OrAq6upKurAhgSCCCaq6bYWOlaZpumaZZWmnabp9nZ2Nhp9hbQ2djY2VpbpBa2dnaW6RwW1rbQRxw29vDGkUMSJHGioqqCigC+AMDgdB2FFFFAH/2Q==";

$female = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD//gA8Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2NjIpLCBxdWFsaXR5ID0gMTAwCv/bAEMAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/bAEMBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/AABEIADIAMgMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APpg/wDB7V+xcfFkVkP2PP2nB4INyI5fEja58LB4mjtC+Dcp4PXxG+mySqnz/Zj41jBPy+eCAa/qP/Yf/b2/Zd/4KIfBiy+On7K/xHs/HXhGS6XTPEGlzQvpPjDwN4iECXM3hnxv4YumN9oOsxQyLNGkolsdQtWS+0q9v7F47lv8Niv0M/4Js/t2ftvfsNfHu21v9hbxPqVp8Uvi3BZfC3/hA4/D9v400f4i3XiDUrW38PaPc+C79ZbDWNcg1uS2bw3dCIX9jezSRW0wgvLyC4AP9uL5efxz0x78e23sPz5peBz6cevA4/Lvgc/jmvwG/wCCNa/8F3/EF74q8f8A/BV/Xfgnofw317wsY/Afwo0zwz4bsfjbovi5tR0ye21fW734eIngzR/DQ0ddWtbrRdS1TXvEE+ozWbmDR47WU3nq/wDwVW+B3/BZ/wCM194Gtv8Agl1+1j+zr+zZ4R0/w7dr8Qbf4n+HLu48e+IvFUmo3TW8+ieJZ/hX8XNFstAi0g2MKWKaJo2pR6it7cy6ndwTW1vagH4nf8Hev/BU3xV+z18KPhz+wJ8CfGureEviV8d9Ob4g/GvXfDOoz6drOjfBS1utS0bRfB6ajYzw3mnSfEXxLZ3dxqPkSR3D+HfC1xYTAWPiAiX/AD5fgx+1l+1B+zpPdXHwF/aF+M/wde+Wdb1Phx8SPFvhC3vBcgidrq00TVbO1uJJATullheTkkOCTXsn/BSXXv2p9V/bU+O+g/tofGW3+PX7Rfw18X3Xwq+IPxH07Vf7Y0PUtQ8AAaB9g8O3a6B4Wi/sXSWtpLK2jg8O6TH5sVxJ9l8yR5ZfhmgD7Cl/4KFft5TyyTS/tn/tSvLNI8srn48/E7LySMXdjjxMBlmJJwAMmivj2igAr6S/Y3+LPhH4C/tZ/s1fGzx9o93r/gn4TfHP4XfETxZo1gzLfah4f8IeMtH1zVYLIq8Ra7+x2Ur20fmRiWZUjLoHLD5tr9Av+CU3wWH7Q/8AwUg/Yt+Dsk3heO28Y/tA+AU1CLxnawX3hvUdK0LVE8Tavomo2F14c8WWWoNr+maNd6JY6fqPh+/0y+1HULS01M2dhNc31sAf7Yvg/wAWeG/H3hTwx458HaxZeIfCXjLQNH8UeGdd02YTWGs6Br9hb6po+qWUwXElrfWF1b3ML4y0cq5AOQNbUdQ0/SNPv9W1W9ttO0zS7O51HUdQvZ47aysbCyhe5vLy7uZmSK3tbW2iknnnlZY4okeR2VVJo0vS9O0TTrDRtG06y0nSNKs7bTtL0vTLSKw07TdPs4UtrOwsLK0jhtrSztLeKKC2treKOCCGNIokRFChNV0rT9d0zUdF1mwtNV0jV7G70vVdL1C2S8sNS03UIJLW+sL60nSSC6s7u1lkt7m3mR4p4ZHjkV1YigD/AA//APgpN8afhf8AtF/t8/tc/HL4LaK+g/Cz4ofHfx/4t8FWUj3DyXWj6lrU7LrrrcyyzW7+KLlLjxK1kXCWB1Y2UMcMNvHEnxHX9Jn/AAdL/sgfA/8AY8/4KR6Z4W/Z98HfDn4ZfD3x78CPAfjm3+Gfw502y0Ow8KamdS8R+HdTnv8ARNP0qxt7GbxBdaI+rQSyXup3N3HI8jtZWyWlqP5s6ACiiigD+33/AIM2/wDgn58NPjX49/aW/bM+MfgHwt8QdH+E0OhfBj4V6V4z0HTvEWi6f478TQW/ivxj4nttN1a1urBtd0PwxDoGlafdvG0lja+LNReJRNNDND/fN4c/ZB/ZR8H/ABGsvi/4R/Zp+A3hX4qabFcxaf8AEPw38JfAmheM7JbyJ7e7Np4i0vQbTVLeW4tpZbWeaK6E0ltLJbPKYXZW/ny/4IZ/sl/Eb/gj1+1N+1H/AMEyPiNd3vjT4WfGtX/a3/ZJ+OCWC2OleP8ARvDMHhn4b/FHwP4hgjU2+k/E7wxYz+BNS1PQ7e4uLa60i3udfsDHZXUcK/1L5x+PHGTzgYzken48AgckUALnoOf0BGO556HB5HHbvRxjqevXjOePQc8cjjp7YpOc4GQAQOvbA9eOw79+hyaXPoDj+fPJHc9fTB7e4B+fn7V//BK7/gnx+3J4/wDD/wAUv2rv2XvAfxn+IHhbw3F4Q0TxV4gu/Fen6hb+GbfUb/VbbRrj/hGvEWiW2qWVpqGqajdWkeqwXrWr3tytu0aSuh/iY/4Owf8AglZ+xD+xB8Ev2U/i/wDsi/ADw/8ABDWvGPxZ8V/DXxvD4P1HxRPpHiKwbwe3iTQDdaVrOuavY22pWNzpGpLBd2EFpdXkN1PHePcLb24i/wBGjIAySQOpY8DA656kY9zg8/wgCvwN8Afsgt/wUy/bVtf+Cgn7VWktrn7Ln7O+qal4S/4J3/ADXonk8O+I7rSdSig8S/tf+PtFkAttWu/G2vafcD4QaTqCXtgfAmneG/F08AnvdOFAH+bN4a/4IY/8Fa/F3hzQPFegfsJfHa80LxPouleIdFu5PDtvZSXWk61Ywalp1zJZX19bX1o89ncwyva3lvb3VuzGK4himR41K/2ic7flAwF4A+YYA4AwCAMDsAMelFAHmHjzTNNufG3wX1O50+xuNS0vxp4iXTNQntLeW+05b74ZeOIb0WF3JG09mLyFEiuhbyRi4iRY5t6qAPUl6j6f0WiigBx6fUjP5gfy4owPQflRRQBDKiSwSxyIskciMkkbqHSRHQK6OrAq6upKurAhgSCCCaq6bYWOlaZpumaZZWmnabp9nZ2Nhp9hbQ2djY2VpbpBa2dnaW6RwW1rbQRxw29vDGkUMSJHGioqqCigC+AMDgdB2FFFFAH/2Q==";
////////////////////////////////////////////////////////////////////////////////////////////
$returnData = array();

if (isset($_POST['form']) && !empty($_POST['form'])) {
    $formArray = array();
    for ($i = 0; $i < count($_POST['form']); $i++) {
        $formArray[$_POST['form'][$i]['name']] = $_POST['form'][$i]['value'];
    }

    //////////////////////////////////////////////////////////
    //activate users
    if (isset($_POST['active'])) {
        if (!empty($_POST['id'])) {
            if (isset($formArray['owner'])) unset($formArray['owner']);
            $userslist = implode(',', $_POST['id']);
            $userslist = MySQL::filter($userslist);
            $datetime = date('Y-m-d H:i:s', time());
            $sql = " UPDATE user_u SET approved = 1, activeState = 1, activation_time = '" . $datetime . "' WHERE
        u_id in (" . $userslist . ") AND office_id = " . $formArray['office_id'] . " AND office_nametag = '" . $formArray['office_nametag'] . "'";
            $result = MySQL::execute($sql);
//printR($result);

            if ($result == TRUE)
                $message = array('type' => 'success', 'message' => 'Activation success!', 'type2' => 'active');
            else
                $message = array('type' => 'error', 'message' => 'Activation unsuccess!');

            $returnData = $message;
            printSortResult($returnData);
        } else {
            $message = array('type' => 'error', 'message' => 'No data was sended1!');
            //$returnArray['message'] = $message;
            $returnData = $message;
            printSortResult($returnData);
        }
    }
    //////////////////////////////////////////////////////////
    //deactivate users
    if (isset($_POST['inactive'])) {
        if (!empty($_POST['id'])) {
            if (isset($formArray['owner'])) unset($formArray['owner']);
//printR($_POST['id']);
            $userslist = implode(',', $_POST['id']);
            $userslist = MySQL::filter($userslist);
            $sql = " UPDATE user_u SET activeState = 0 WHERE
        u_id in (" . $userslist . ") AND office_id = " . $formArray['office_id'] . " AND office_nametag = '" . $formArray['office_nametag'] . "'";
            $result = MySQL::execute($sql);
//printR($result);

            if ($result == TRUE)
                $message = array('type' => 'success', 'message' => 'Inctivation success!', 'type2' => 'inactive');
            else
                $message = array('type' => 'error', 'message' => 'Inctivation unsuccess!');

            $returnData = $message;
            printSortResult($returnData);
        } else {
            $message = array('type' => 'error', 'message' => 'No data was sended1!');
            //$returnArray['message'] = $message;
            $returnData = $message;
            printSortResult($returnData);
        }
    }

    //////////////////////////////////////////////////////////
    //delete users
    if (isset($_POST['delete'])) {
        if (!empty($_POST['id'])) {
            if (isset($formArray['owner'])) unset($formArray['owner']);
//printR($_POST);
            $del_id = array();
            foreach ($_POST['id'] as $k => $v)
                $del_id[] = MySQL::filter($v);
            $delIds = implode(',', $del_id);
            $sqlDelete = "DELETE FROM user_u WHERE u_id IN (" . $delIds . ") AND office_id = " . $formArray['office_id'] . " AND office_nametag = '" . $formArray['office_nametag'] . "'";
            $result = MySQL::execute1($sqlDelete);
            $sqlDelete = "DELETE FROM user_usergroupUsers WHERE u_id IN (" . $delIds . ") AND office_id = " . $formArray['office_id'] . " AND office_nametag = '" . $formArray['office_nametag'] . "'";
            $result = MySQL::execute1($sqlDelete);

            //training groupbol is torolni kell
            $delID = MySQL::filter($_POST['id'][0]['id']);
            $sqlDelete = "DELETE FROM user_traininggroupUsers WHERE u_id IN (" . $delIds . ") AND office_id = " . $formArray['office_id'] . " AND office_nametag = '" . $formArray['office_nametag'] . "'";
            $result = MySQL::execute($sqlDelete);


//printR( $result);
            if ($result == TRUE)
                $message = array('type' => 'success', 'message' => 'Delete was successfully!', 'type2' => 'delete');
            else
                $message = array('type' => 'error', 'message' => 'Nothing to delete yet!!!!!!!');

            $returnData = $message;
            printSortResult($returnData);
        } else {
            $message = array('type' => 'error', 'message' => 'No data was sended1!');
            //$returnArray['message'] = $message;
            $returnData = $message;
            printSortResult($returnData);
        }
    }

    //////////////////////////////////////////////////////////
    //remove users from group (department / training group
    if (isset($_POST['remove'])) {
        if (!empty($_POST['id'])) {
            if (isset($formArray['owner'])) unset($formArray['owner']);

            $del_id = array();
            foreach ($_POST['id'] as $k => $v)
                $del_id[] = MySQL::filter($v);

//printR($del_id);
//exit;      
            $delIds = implode(',', $del_id);

            // usergroupból veszem ki, akkor a department tagot nullázom
            if ($_POST['remove'] == 'usersGroupList') {
                $sqlUpdate = "UPDATE user_u SET department = '' WHERE u_id IN (" . $delIds . ") AND office_id = " . $formArray['office_id'] . " AND office_nametag = '" . $formArray['office_nametag'] . "'";
                $result = MySQL::execute1($sqlUpdate);
//printR($result);
                //törlöm a usergroupUser táblából
                $sqlDelete = "DELETE FROM user_usergroupUsers WHERE u_id IN (" . $delIds . ") AND office_id = " . $formArray['office_id'] . " AND office_nametag = '" . $formArray['office_nametag'] . "'";
                $result = MySQL::execute1($sqlDelete);
            } else if ($_POST['remove'] == 'trainingGroupList') {

                //training groupbol is torolni kell
                $delID = MySQL::filter($_POST['id'][0]['id']);
                $sqlDelete = "DELETE FROM user_traininggroupUsers WHERE u_id IN (" . $delIds . ") AND office_id = " . $formArray['office_id'] . " AND office_nametag = '" . $formArray['office_nametag'] . "'";
                $result = MySQL::execute($sqlDelete);
            }

//printR( $result);
            if ($result == true)
                $message = array('type' => 'success', 'message' => 'Delete was successfully!');
            else
                $message = array('type' => 'error', 'message' => 'Delete was unsuccessfully!');

            //$returnArray['message'] = $message;
            $returnData = $message;
            printSortResult($returnData);
        } else {
            $message = array('type' => 'error', 'message' => 'No data was sended1!');
            //$returnArray['message'] = $message;
            $returnData = $message;
            printSortResult($returnData);
        }
    }
    //////////////////////////////////////////////////////////
    //update users group/department in user_u and user_usergroupUsers
    //check if user prev dept was empty
    if (isset($_POST['groupChange'])) {
        if (!empty($_POST['id'])) {
            //if (isset($formArray['owner'])) unset($formArray['owner']);
            $oid = $formArray['office_id'];
            $ont = $formArray['office_nametag'];
            $ow = $formArray['owner'];
            $users = array();
            $onDuplicate = array();
            foreach ($_POST['id'] as $row) {
                $users[] = $row['id'];
                $groupName = $row['groupName'];
                $groupid = $row['groupid'];
                $onDuplicate[] = "(" . $row['id'] . ", " . $groupid . ", " . $oid . ", '" . $ont . "', " . $ow . ")";
            }
            $sql = "
        UPDATE user_u 
        SET department = '" . $groupName . "'
        WHERE u_id IN (" . implode(',', $users) . ") AND office_id = " . $oid . " AND office_nametag = '" . $ont . "'
      ";
            $result = MySQL::execute($sql);
            if ($result == TRUE) {
                $sqlReplace = "
          INSERT into user_usergroupUsers 
          ( u_id, usergroup_id, office_id, office_nametag, owner) 
          VALUES 
          " . implode(',', $onDuplicate) . "
          ON DUPLICATE KEY 
          UPDATE usergroup_id = VALUES(usergroup_id)
        ";
//printR( $sqlReplace );
                $result = MySQL::execute1($sqlReplace);
//printR( $result );
                if ($result == TRUE)
                    $message = array('type' => 'success', 'message' => 'Membership successfully updated!');
                else
                    $message = array('type' => 'error', 'message' => 'Update membership was unsuccessfull!');

                $returnData = $message; //$returnArray;
                printSortResult($returnData);
            } else //user tablaban nem sikerült
                $message = array('type' => 'error', 'message' => 'Update membership was unsuccessfull!');

            //$returnArray['message'] = $message;
            $returnData = $message; //$returnArray;
            printSortResult($returnData);
        } else {
            $message = array('type' => 'error', 'message' => 'No data was sended1!');
            //$returnArray['message'] = $message;
            $returnData = $message; //$returnArray;
            printSortResult($returnData);
        }
    }

    //////////////////////////////////////////////////////////
    //load existing users
    if (isset($_POST['load']) && $_POST['load'] == 'load') {
        if (isset($formArray['id'])) unset($formArray['id']);
        if (isset($formArray['name'])) unset($formArray['name']);
        if (isset($formArray['owner'])) unset($formArray['owner']);

        $options = array(
            'table' => 'user_u',
            'fields' => 'u_id, elotag, vezeteknev, keresztnev, full_name, user_email, createdDate, ctime, users_kep, department, gender, birthDate, language, schools, position, activeState',
            'condition' => $formArray,
            'conditionExtra' => '', //"name LIKE '%".$newDiskareaName['name']."%'",
            'order' => 'full_name',
            'limit' => 100
        );
        //$result = MySQL::select($options);
        $sql = "SELECT u_id, elotag, vezeteknev, keresztnev, full_name, user_email, createdDate, ctime, users_kep,
    department, gender, birthDate, language, schools, position, activeState FROM user_u WHERE office_id = "
            . $_SESSION['office_id'] . " AND office_nametag = '" . $_SESSION['office_nametag'] . "' ORDER BY full_name";
        $result = MySQL::query($sql, false, false);


        $usersArray = array();
        $db = count($result);
        $urlRegex = URL_REGEX;

        foreach ($result as &$row) {
            $usersArray[] = array(
                'id' => $row['u_id'],
                'pre' => $row['elotag'],
                'forname' => $row['keresztnev'],
                'surname' => $row['vezeteknev'],
                'fullname' => $row['full_name'],
                'department' => (is_null($row['department']) || $row['department'] == '') ? '' : $row['department'],
                'doname' => is_null($row['department']) ? '' : normalize_special_characters(str_replace(' ', '', strtolower($row['department']))),
                'registered' => date('Y.m.d', strtotime($row['createdDate'])),
                'skills' => array(),
                'img' => (is_null($row['users_kep']) || $row['users_kep'] == "") ? ($row['gender'] == "férfi" ? $male : $female) : ($row['users_kep']),
                'email' => $row['user_email'],
                'gender' => $row['gender'],
                //ell hogy nem 0000.00
                'birth' => ($row['birthDate'] == '0000-00-00') ? '' : date('Y.m.d', strtotime($row['birthDate'])),
                'languages' => $row['language'], //$row['language'],
                'schools' => $row['schools'], //$row['schools'],
                'position' => $row['position'], //$row['position']
                'active' => ($row['activeState'] == 1) ? 'active' : 'inactive'
            );
        }
        printResult($usersArray);

//print_r( $result);
//exit;
    }

    //////////////////////////////////////////////////////////
    //load selected users
    if (isset($_POST['load']) && $_POST['load'] == 'loadOne' && !empty($_POST['id'])) {
//print_r( $_POST);
        if (isset($formArray['id'])) unset($formArray['id']);
        if (isset($formArray['name'])) unset($formArray['name']);
        if (isset($formArray['owner'])) unset($formArray['owner']);

        //$result = MySQL::select($options);
        $sql = "
            SELECT u_id, elotag, vezeteknev, keresztnev, full_name, user_email, createdDate, ctime, users_kep, department, gender, birthDate, language, schools, position, activeState
            FROM user_u
            WHERE u_id = " . $_POST['id'] . " AND office_id = " . $_SESSION['office_id'] . " AND office_nametag = '" .
            $_SESSION['office_nametag'] . "'
            ORDER BY full_name LIMIT 1";

        $result = MySQL::query($sql, false, false);

//print_r( $result);
        $usersArray = array();
        $db = count($result);
        $urlRegex = URL_REGEX;

        foreach ($result as &$row) {
            $usersArray[] = array(
                'id' => $row['u_id'],
                'pre' => $row['elotag'],
                'forname' => $row['keresztnev'],
                'surname' => $row['vezeteknev'],
                'fullname' => $row['full_name'],
                'department' => (is_null($row['department']) || $row['department'] == '') ? '' : $row['department'],
                'doname' => is_null($row['department']) ? '' : normalize_special_characters(str_replace(' ', '', strtolower($row['department']))),
                'registered' => date('Y.m.d', strtotime($row['createdDate'])),
                'skills' => array(),
                'img' => (is_null($row['users_kep']) || $row['users_kep'] == "") ? ($row['gender'] == "férfi" ? $male : $female) : ($row['users_kep']),
                'email' => $row['user_email'],
                'gender' => $row['gender'],
                //ell hogy nem 0000.00
                'birth' => ($row['birthDate'] == '0000-00-00') ? '' : date('Y.m.d', strtotime($row['birthDate'])),
                'languages' => $row['language'], //$row['language'],
                'schools' => $row['schools'], //$row['schools'],
                'position' => $row['position'], //$row['position']
                'active' => ($row['activeState'] == 1) ? 'active' : 'inactive'
            );
        }
        printResult($usersArray);

//print_r( $result);
//exit;
    }
    //////////////////////////////////////////////////////////
    //save individual user
    if (isset($_POST['save'])) {
        if (!empty($_POST['id'])) {

            //get registar user
            $sqlRegistrar = "SELECT full_name FROM user_u WHERE u_id = " . $formArray['owner'] . " AND office_id = " . $formArray['office_id'] . " LIMIT 1";
            $registrar1 = MySQL::query($sqlRegistrar, false, false);
            $registrar = $registrar1[0]['full_name'];

            $formUser = array();
            for ($i = 0; $i < count($_POST['id']); $i++) {
                $formUser[$_POST['id'][$i]['name']] = $_POST['id'][$i]['value'];
            }

            if (!is_null($formUser['vezeteknev']) && !is_null($formUser['keresztnev']) && !is_null($formUser['gender']) && !is_null($formUser['email'])) {
                $elotag = (strlen(str_replace(' ', '', $formUser['elotag'])) == 0 ? '' : $formUser['elotag'] . ' ');
                $fullname = $elotag . $formUser['vezeteknev'] . ' ' . $formUser['keresztnev'];
                $formUser['full_name'] = $fullname;
                $formUser['gender'] = ($formUser['gender'] == 'male') ? 'férfi' : 'nő';
                $formUser['user_email'] = $formUser['email'];
                $owner = $formArray['owner'];
                unset($formUser['email']);
                unset($formUser['something']);
                if (isset($formArray['owner'])) unset($formArray['owner']);

                //pwd
                $pwd = rand_string(8);
                $oid = $formArray['office_id'];
                $ont = $formArray['office_nametag'];
                //create activation code
                $email = $formUser['user_email'];
                $key = uniqid("", true);
                $enc = new Encryption();
                $enc->addKey($email);
                $encrypted = $enc->encode($key);

                //data to store in db
                $array_of_values = array(
                    'elotag' => $formUser['elotag'],
                    'keresztnev' => $formUser['keresztnev'],
                    'vezeteknev' => $formUser['vezeteknev'],
                    'user_email' => $formUser['user_email'],
                    'department' => $formUser['department'],
                    'birthDate' => $formUser['birth'],
                    'gender' => $formUser['gender'],
                    'language' => $formUser['language'],
                    'schools' => $formUser['schools'],
                    'skills' => $formUser['skills'],
                    'createdDate' => date('Y-m-d H:j:s', time()),
                    'full_name' => $fullname,
                    'pwd' => HashPassword($pwd),
                    'user_level' => 3,
                    'office_id' => $oid,
                    'office_nametag' => $ont,
                    'approved' => 0,
                    'user_type' => 'office',
                    'activeState' => 0,
                    'banned' => 0,
                    'activation_code' => $key,
                    'cryptedText' => $encrypted
                );

                //check if exist or not?
                $sql = "SELECT full_name, user_email FROM user_u WHERE office_id = " . $_SESSION['office_id'] . " AND office_nametag = '" . $_SESSION['office_nametag'] . "' AND full_name = '" . $fullname . "' AND user_email = '" . $formUser['user_email'] . "'";
                $rr = MySQL::query($sql, false, false);

                if (empty($rr[0])) { //user dosen't exist
                    $resUser = MySQL::insertIgnore('user_u', $array_of_values);
//$resUser = 1;
                    if (is_numeric($resUser)) {
                        User::globalSkillUserAdd($array_of_values['user_email'],$_SESSION['domain']);
                        //insert success
                        //check if department is not empty add row to table if not exist
                        $returnGroup = array();
                        if (!is_null($array_of_values['department']) &&
                            ($array_of_values['department'] != '') &&
                            strlen(str_replace(' ', '', $array_of_values['department'])) > 0
                        ) {
                            $array_of_values2 = array(
                                'name' => $array_of_values['department'],
                                'office_id' => $oid,
                                'office_nametag' => $ont,
                                //'createdDate'=>date('Y-m-d H:j:s', time()),
                                'owner' => $owner
                            );
                            //mégegyszer ua groupot nem hozom létre
                            $resGroup = MySQL::insertIgnore('user_usergroup', $array_of_values2);
                            //ha mar letezik a usergroup, akkor lekerdezem az ID-jét
                            $typeOfGroup = 'new';
                            if (is_numeric($resGroup) && $resGroup == 0) {
                                $tres = MySQL::query("SELECT usergroup_id FROM user_usergroup WHERE name ='" . $array_of_values['department'] . "' AND office_id = " . $oid . " AND office_nametag = '" . $ont . "'", false, false);
                                $resGroup = $tres[0]['usergroup_id'];
                                //$returnGroup = array('id'=> $resGroup, 'name'=> $array_of_values['department']);
                                $typeOfGroup = 'exist';
                            }

                            $returnGroup = array('type' => $typeOfGroup, 'id' => $resGroup, 'name' => $array_of_values['department']);

                            //insert user into usergroupUsers table
                            $array_of_values3 = array(
                                'usergroup_id' => $resGroup,
                                'u_id' => $resUser,
                                'office_id' => $oid,
                                'office_nametag' => $ont,
                                //'createdDate'=>date('Y-m-d H:j:s', time()),
                                'owner' => $owner
                            );
                            $res2 = MySQL::insertIgnore('user_usergroupUsers', $array_of_values3);

                        }

                        //create user array for sending email
                        $newUserArray = array();
                        //$newUserArray[] = array('name' =>$fullname, 'email' =>$array_of_values['user_email'],'password' =>$pwd);
                        $newUserArray[] = array('forname' => $formUser['keresztnev'], 'name' => $fullname, 'email' => $array_of_values['user_email'], 'password' => $pwd);

                        //create retur array for user
                        $usersArray[] = array(
                            'id' => $resUser,
                            'pre' => $array_of_values['elotag'],
                            'forname' => $array_of_values['keresztnev'],
                            'surname' => $array_of_values['vezeteknev'],
                            'fullname' => $array_of_values['full_name'],
                            'department' => $array_of_values['department'],
                            'doname' => is_null($array_of_values['department']) ? '' : normalize_special_characters(str_replace(' ', '', strtolower($array_of_values['department']))),
                            'registered' => date('Y.m.d', strtotime($array_of_values['createdDate'])),
                            'skills' => $array_of_values['skills'],
                            'img' => '', //$array_of_values['user_email'],
                            'email' => $array_of_values['user_email'],
                            'gender' => $array_of_values['gender'],
                            'birth' => $array_of_values['birthDate'],
                            'languages' => $array_of_values['language'],
                            'schools' => $array_of_values['schools'],
                            'active' => 'inactive'
                        );

                        $returnArray['users']['result'] = $usersArray;
                        $returnArray['group'] = $returnGroup;
//printR($newUserArray);
                        foreach ($newUserArray as $user)
                            SkillMailer::sendRegisteredEmail($user, $registrar, $encrypted);
                        $returnArray['message'] = array('type' => 'success', 'message' => 'User created. Email from registration sended');
                        //$returnData = $message;
                        printSortResult($returnArray);

                    } else {
                        $message = array('type' => 'error', 'message' => 'Insert user unsuccessfull');
                    }
                } else {
                    $message = array('type' => 'error', 'message' => $fullname . ' - User exist');
                }
                /**/
                //printR( $formUser );
            } else {
                $message = array('type' => 'error', 'message' => 'Main data is not correct');
            }

            //$returnArray['message'] = $message;
            $returnData = $message;
            printSortResult($returnData);
        } else {
            $message = array('type' => 'error', 'message' => 'No data was sended1!');
            //$returnArray['message'] = $message;
            $returnData = $message;
            printSortResult($returnData);
        }
    }

    //update user data
    if (isset($_POST['update']) && $_POST['update'] == 'update') {
        if (!empty($_POST['id'])) {
            if (isset($formArray['owner'])) unset($formArray['owner']);
            $userArray = array();
            for ($i = 0; $i < count($_POST['id']); $i++) {
                $userArray[$_POST['id'][$i]['name']] = $_POST['id'][$i]['value'];
            }
            if (isset($userArray['email'])) unset($userArray['email']);
            if (isset($userArray['id'])) {
                $formArray['u_id'] = $userArray['id'];
                unset($userArray['id']);
            }
//printR($formArray);
            $result = MySQL::update('user_u', $userArray, $formArray);
//printR( $result );
            if ($result == TRUE)
                $message = array('type' => 'success', 'message' => 'Data updated!');
            else
                $message = array('type' => 'error', 'message' => 'Can\t be updated!');

            $returnArray['message'] = $message;
            $returnData = $returnArray;
            printSortResult($message);

        } else {
            $message = array('type' => 'error', 'message' => 'No data was sended1!');
            //$returnArray['message'] = $message;
            $returnData = $message;
            printSortResult($returnData);
        }
    }

} else {
    $message = array('type' => 'error', 'message' => 'No data was sended1!');
    //$returnArray['message'] = $message;
    $returnData = $message;
    printSortResult($returnData);
}
$_SESSION['LAST_ACTIVITY'] = time();
exit;

header('Pragma: no-cache');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Content-Disposition: inline; filename="files.json"');
// Prevent Internet Explorer from MIME-sniffing the content-type:
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Credentials:false');
header('Access-Control-Allow-Headers:Content-Type, Content-Range, Content-Disposition, Content-Description');
header('Access-Control-Allow-Origin:*');
header('Content-type: application/json');
header('Expires:Thu, 19 Nov 1981 08:52:00 GMT');
header('Keep-Alive:timeout=15, max=100');
header('Pragma:no-cache');
$resF['result'] = $returnData;
$json = json_encode($resF, true);
echo $json;

?>