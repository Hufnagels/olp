<?php
/*require_once ( $_SERVER['DOCUMENT_ROOT'].'/../include/header/_header_auth.php' );
require_once ($_SERVER['DOCUMENT_ROOT'].'/../include/header/_header_header_text.php');
require_once ($_SERVER['DOCUMENT_ROOT'].'/../include/header/_header_include_base.php');
require_once ($_SERVER['DOCUMENT_ROOT'].'/../include/class/class.encrypt.php');
*/