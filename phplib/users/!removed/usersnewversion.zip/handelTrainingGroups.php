<?php
require_once ($_SERVER['DOCUMENT_ROOT'] . '/../include/header/_header_auth.php');

include ($_SERVER['DOCUMENT_ROOT'] . '/../include/header/_header_header_text.php');
include ($_SERVER['DOCUMENT_ROOT'] . '/../include/header/_header_include_base.php');

if (isset($_POST['form']) && !empty($_POST['form'])) {
    $formArray = createArrayFromPostNV();

    //load training group
    if (isset($_POST['load']) && $_POST['load'] == 'load') {
        $mediaBoxesArray = array();
        $sql2 = "
      SELECT 
          box.traininggroup_id AS groupid, box.name AS name, box.doname, GROUP_CONCAT(users.u_id) AS members, COUNT(users.u_id) AS badge
      FROM user_traininggroup box
      LEFT JOIN user_traininggroupUsers users
      ON box.traininggroup_id = users.traininggroup_id
      WHERE box.office_id = " . MySQL::filter($_SESSION['office_id']) . " AND box.office_nametag = '" . MySQL::filter($_SESSION['office_nametag']) . "' GROUP BY groupid ORDER BY box.name ASC";
        $query2 = MySQL::query($sql2, false, false);

        //ha van usergroup
        if (!empty($query2)) {
            $db = count($query2);
            for ($j = 0; $j < $db; $j++) {
                $mediaBoxesArray[$j] = array(
                    "id" => $query2[$j]['groupid'],
                    "name" => $query2[$j]['name'],
                    "doname" => $query2[$j]['doname'],
                    "badge" => $query2[$j]['badge'],
                    'members' => $query2[$j]['members']
                );
            }
            $returnData['result'] = $mediaBoxesArray;
            //$returnData['message'] =array('type' => 'success', 'message' => 'All loaded!');
            printSortResult($returnData);
        } else {
            $returnData = array('type' => 'error', 'message' => 'No users!');
            printSortResult($returnData);
        }
    }

    //save new training group
    if (isset($_POST['save']) && $_POST['save'] == 'save' && isset($_POST['id'])) {
        //@todo nem megy a felulet, igy ezt most nem implementalom!

        $userGroupName = MySQL::filter($_POST['id']);
        $doname = normalize_special_characters(str_replace(' ', '', strtolower($userGroupName)));
        $userGroupArray = array('name' => $userGroupName, 'doname' => $doname);
        $array_of_values = array_merge($formArray, $userGroupArray);
        $insertID = MySQL::insert('user_traininggroup', $array_of_values);
        if (is_numeric($insertID))
            $returnData = array('resultId' => $insertID);
        else
            $returnData = array('error' => 'Training Group save was unsuccessfull!');

        printSortResult($returnData);
    }

    //rename training group
    if (isset($_POST['rename']) && $_POST['rename'] == 'rename' && isset($_POST['id'][0]) && !empty($_POST['id'][0])) {

        $userGroupName = MySQL::filter($_POST['id'][0]['newname']);
        $userGroupId = MySQL::filter($_POST['id'][0]['id']);

        $sortname = normalize_special_characters(strtolower($userGroupName));
        $sortname = str_replace(' ', '', $sortname);

        $trainingGroup = new UserTrainingGroup($userGroupId);
        $trainingGroup->setDBField('name', $userGroupName);
        $trainingGroup->setDBField('doname', $sortname);

        $result = $trainingGroup->save();

        if ($result == true) {
            $returnData = array('sortname' => $sortname, 'newname' => $userGroupName);
        } else {
            $returnData = array('error' => 'Training group rename was unsuccessfull!');
        }

        printSortResult($returnData);
    }

    //delete training group
    if (isset($_POST['delete']) && $_POST['delete'] !== '' && isset($_POST['id']) && !empty($_POST['id'])) {

        /*
         * @todo ezt nem ertem, a torlesnel az sqlt is meg kellene majd nezni!
        $users = array();
        foreach ($_POST['id']['users'] as $row)
            $users[] = $row['id'];
        //set sers department to ''
        */

        $delID = MySQL::filter($_POST['id'][0]['id']);

        $trainingGroup = new UserTrainingGroup($delID);
        $trainingGroup->remove();

        //if ($result == TRUE)
        $returnData = array('type' => 'success', 'message' => 'Training group successfully removed!');
        //else $returnData = array('type' => 'error', 'message' => 'Training group can\'t be deleted!');

        printSortResult($returnData);
    }

    //add users to traininggroup
    if (isset($_POST['add']) && $_POST['add'] == 'add' && isset($_POST['id'][0]) && !empty($_POST['id'][0])) {


        $dbtr = new DBTransaction();

        $glbResult = true;
        foreach ($_POST['id'] as $row) {
            if (!UserTrainingGroup::addUserToGroup($row['groupid'], $row['id'], $_SESSION['u_id'], $_SESSION['office_id'], $_SESSION['office_nametag']))
                $glbResult = false;
        }

        if ($glbResult) $dbtr->destroy();

        if ($glbResult == true) {
            $returnArray = array('type' => 'success', 'message' => 'Users successfully added to training group!');
        } else {
            $returnArray = array('type' => 'error', 'message' => 'Users can\'t be added to training group!');
        }

        printSortResult($returnArray);
    }

} else {
    $returnData = array('type' => 'error', 'message' => 'Misspelled data sent to server!');
    printSortResult($returnData);
}
$_SESSION['LAST_ACTIVITY'] = time();

?>