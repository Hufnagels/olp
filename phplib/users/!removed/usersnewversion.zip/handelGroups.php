<?php
require_once ( $_SERVER['DOCUMENT_ROOT'].'/../include/header/_header_auth.php' );
require_once ($_SERVER['DOCUMENT_ROOT'].'/../include/header/_header_header_text.php');
require_once ($_SERVER['DOCUMENT_ROOT'].'/../include/header/_header_include_base.php');


if ( isset($_POST['form']) && !empty($_POST['form']) ){
  $formArray = createArrayFromPostNV();
  
  //load usergroup
  if ( isset($_POST['load'][0]) && $_POST['load'] == 'load') {
    $mediaBoxesArray = array();
    $organized = 0;
    
    //count all users
    $sql = "
    SELECT COUNT(u_id) AS badge FROM user_u
      WHERE office_id = ".MySQL::filter($_SESSION['office_id'])." AND office_nametag = '".MySQL::filter($_SESSION['office_nametag'])."'";
  
    $query = MySQL::query($sql, false, false);

    $mediaBoxesArray[0] = array(
      "id" => 'all',
      "name" => 'View all',
      "doname" => 'viewall',
      "badge" => $query[0]['badge']
    );
    if(!empty($query)){
      //collect usergroups and membercount
      $sql2 = "
        SELECT 
          box.usergroup_id AS groupid, box.name AS name, box.doname, COUNT(users.u_id) AS badge
        FROM user_usergroup box
        LEFT JOIN user_usergroupUsers users
          ON box.usergroup_id = users.usergroup_id
          WHERE box.office_id = ".MySQL::filter($_SESSION['office_id'])." AND box.office_nametag = '".MySQL::filter($_SESSION['office_nametag'])."' GROUP BY box.usergroup_id ORDER BY box.name ASC";
      $query2 = MySQL::query($sql2, false, false);
      
      //ha van usergroup
      if(!empty($query2)){
        foreach( $query2 as $row)
          $organized = $organized + intval($row['badge']);
        //not in list count
        $mediaBoxesArray[1] = array(
          "id" => 'notInList',
          "name" => 'Unorganized',
          "doname" => 'unorganized',
          "badge" => $query[0]['badge']-$organized
        );

        //collect return list
        $db = count($query2);
        for ($j=0;$j<$db;$j++){
          $nameTag = $query2[$j]['name'];
          $idTag = $query2[$j]['groupid'];
          $badge = $query2[$j]['badge'];
          $doname = $query2[$j]['doname'];
          $mediaBoxesArray[$j+2] = array(
            "id" => $idTag,
            "name" => $nameTag,
            "doname" => $doname,
            "badge" => $badge
          );
        }
        $returnData['result'] = $mediaBoxesArray;
      } else {
//printR($mediaBoxesArray);
        $mediaBoxesArray[1] = array(
          "id" => 'notInList',
          "name" => 'Unorganized',
          "doname" => 'unorganized',
          "badge" => $query[0]['badge']
        );
        $returnData['result'] = $mediaBoxesArray;
      }
    } else {
      $returnData = array('error' => 'No users!');
    }
//printR($result);
  }
  
  //save new usergroup
  if ( isset($_POST['save']) && $_POST['save'] == 'save' && isset($_POST['id']) ){
    //$formArray['createdDate'] = date( "Y-m-d H:i:s" , time() );
    $userGroupName = MySQL::filter( $_POST['id'] );
    $doname = normalize_special_characters(str_replace( ' ', '', strtolower($userGroupName) ));
    $userGroupArray = array('name' => $userGroupName, 'doname' => $doname);
    $array_of_values = array_merge( $formArray, $userGroupArray );
    $insertID = MySQL::insert('user_usergroup',$array_of_values);
    if(is_numeric($insertID))
      $returnData =array('resultId' => $insertID);
    else
      $returnData = array('error' => 'Department save was unsuccessfull!');
    
  }
  
  //rename usergroup
  if ( isset($_POST['rename']) && $_POST['rename'] == 'rename' && isset($_POST[id][0]) && !empty($_POST[id][0]) ){
//printR($_POST);
    //$formArray['createdDate'] = date( "Y-m-d H:i:s" , time() );
    $userGroupName = MySQL::filter( $_POST['id'][0]['newname'] );
    $userGroupId = MySQL::filter( $_POST['id'][0]['id'] );
    $userGroupOldName = MySQL::filter( $_POST['id'][0]['oldname'] );
    
    $sortname = normalize_special_characters( strtolower( $userGroupName ) );
    $sortname = str_replace( ' ', '', $sortname );
    
    $userGroupArray = array('usergroup_id' => $userGroupId);
    $array_of_conditions = array_merge( $formArray, $userGroupArray );
    $whatToSet = array('name' => $userGroupName);
//printR($whatToSet);
//printR($array_of_conditions);
//$returnData = array('sortname' => $sortname, 'newname' => $userGroupName);
//exit;

    $result = MySQL::update('user_usergroup',$whatToSet, $array_of_conditions);
    //$result = true;
    if($result == true){
      $whatToSet = array('department' => $userGroupName);
      $array_of_conditions['department'] = $userGroupOldName;
      unset($array_of_conditions['usergroup_id']);
      unset($array_of_conditions['owner']);
//printR($whatToSet);
//printR($array_of_conditions);
      $result2 = MySQL::update('user_u',$whatToSet, $array_of_conditions);
//printR($result2);
      $returnData = array('sortname' => $sortname, 'newname' => $userGroupName);
    }else{
      $returnData = array('error' => 'Usergroup rename was unsuccessfull!');
    }
/**/
//printR($result);
  }
  
  //delete usergroup
  if ( isset($_POST['delete']) && $_POST['delete'] !== '' && isset($_POST['id']) && !empty($_POST['id']) ){

    $users= array();
    foreach($_POST['id']['users'] as $row )
      $users[] = $row['id'];
    //set sers department to ''
    $sqlUser = "UPDATE user_u SET department = '' WHERE u_id IN (".implode(',',$users).") AND office_id = ".$_SESSION['office_id'];
//print_r($sqlUser);
    $result = MySQL::execute($sqlUser);
    
    $delID = MySQL::filter( $_POST['id']['groupid'] );
    $sqlDelete = "DELETE FROM user_usergroup, user_usergroupUsers USING user_usergroup LEFT JOIN user_usergroupUsers on (user_usergroupUsers.usergroup_id = user_usergroup.usergroup_id ) WHERE user_usergroup.usergroup_id = ".$delID." AND user_usergroup.office_id = ".$_SESSION['office_id'];
//print_r($sqlDelete);
//exit;
    $result = MySQL::execute($sqlDelete);
    $rows = MySQL::affected_rows();
//printR($rows);
    if ($rows == 0) {
      $sqlDelete = "DELETE FROM user_usergroup WHERE user_usergroup.usergroup_id = ".$delID." AND user_usergroup.office_id = ".$_SESSION['office_id'];
//print_r($sqlDelete);
      $result = MySQL::execute($sqlDelete);
    }
    if($result == TRUE)
      $returnData = array('type'=> 'success', 'message' => 'Department deleted successfully');
    else
      $returnData = array('type'=> 'error', 'message' => 'Department can\'t be deleted!');
  }

} else {
  $returnData = array('error' => 'Misspelled data sent to server!');
}
$_SESSION['LAST_ACTIVITY'] = time();
header('Pragma: no-cache');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Content-Disposition: inline; filename="files.json"');
// Prevent Internet Explorer from MIME-sniffing the content-type:
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Credentials:false');
header('Access-Control-Allow-Headers:Content-Type, Content-Range, Content-Disposition, Content-Description');
header('Access-Control-Allow-Origin:*');
header('Content-type: application/json');
header('Expires:Thu, 19 Nov 1981 08:52:00 GMT');
header('Keep-Alive:timeout=15, max=100');
header('Pragma:no-cache');
//$resF['result'] = $mediaFilesArray;
$json = json_encode($returnData, true);
echo $json;
?>