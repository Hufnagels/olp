<?php

require_once ($_SERVER['DOCUMENT_ROOT'] . '/../include/config.php');
require_once ($_SERVER['DOCUMENT_ROOT'] . '/../include/header/_header_auth.php');
require_once ($_SERVER['DOCUMENT_ROOT'] . '/../include/header/_header_header_text.php');
require_once ($_SERVER['DOCUMENT_ROOT'] . '/../include/header/_header_include_base.php');
require_once ($_SERVER['DOCUMENT_ROOT'] . '/../include/class/class.encrypt.php');

$_SESSION['LAST_ACTIVITY'] = time();

if (!isset($_FILES["files"]) || !is_uploaded_file($_FILES["files"]["tmp_name"][0]) || $_FILES["files"]["error"][0] != 0) {
    $returnData = array('type' => 'error', 'message' => 'ERROR:invalid upload');
    printSortResult($returnData);
    exit(0);
}

if (isset($_POST['form']) && !empty($_POST['form'])) {
    $dirName = $_SERVER['DOCUMENT_ROOT'] . '/../media/_zip/';
    $formArray = array();
    $tempArray = explode('&', $_POST['form']);
    foreach ($tempArray as $row) {
        $data = explode('=', $row);
        $formArray[$data[0]] = $data[1];
    }

    if (isset($formArray['id'])) unset($formArray['id']);
    if (isset($formArray['name'])) unset($formArray['name']);
    $oid = $_SESSION['office_id'];
    $ont = $_SESSION['office_nametag'];
    $ow = $_SESSION['u_id'];

    if ($_FILES['files']['size'][0] > 0) {
        $result = '';
        //get the csv file - force CSV
        $file = $dirName . pathinfo($_FILES['files']['name'][0], PATHINFO_FILENAME) . '_' . time() . '.csv';

        if (move_uploaded_file($_FILES['files']['tmp_name'][0], $file)) {
            $sqlRegistrar = "SELECT full_name FROM user_u WHERE u_id = " . MySQL::filter($_SESSION['u_id']) . " AND office_id = " . MySQL::filter($_SESSION['office_id']) . " LIMIT 1";

            $registrar1 = MySQL::query($sqlRegistrar, false, false);
            $registrar = $registrar1[0]['full_name'];

            $handle = fopen($file, "r");

            //load first row
            $header = fgetcsv($handle, 1000, ";", "'");

            //check if header presented?
            if ($header[0] == 'elotag')
            {
                //contains: full name, email, pwd
                $newUserArray = array();
                $newGroupArray = array();
                $newGroupUser = array();
                $returnUserArray = array();
                $message = array();
                while (($data = fgetcsv($handle, 1000, ";")) !== FALSE)
                {
                    if (!empty($data)) {
                        if (is_numeric($data[0]))
                            $data[0] = '';
                        //check if file is not UTF-8 encoded, convert text to it
                        for ($i = 0; $i < count($data); $i++) {
                            if (mb_detect_encoding($data[$i], 'UTF-8', true) === FALSE)
                                $data[$i] = iconv('ISO 8859-2', 'UTF-8', $data[$i]);

                            $values[] = $data[$i];
                        }
                        //full_name
                        $elotag = (strlen(str_replace(' ', '', $values[0])) == 0 ? '' : $values[0] . ' ');
                        $fullname = str_replace("'", "", $elotag) . str_replace("'", "", $values[1]) . ' ' . str_replace("'", "", $values[2]);
                        //pwd
                        $pwd = rand_string(8);
                        //create activation code
                        $email = $values[3];
                        $key = uniqid("", true);
                        $enc = new Encryption();
                        $enc->addKey($email);
                        $encrypted = $enc->encode($key);

                        $array_of_values = array(
                            'elotag' => $values[0],
                            'keresztnev' => $values[2],
                            'vezeteknev' => $values[1],
                            'user_email' => $values[3],
                            'department' => $elotag = (strlen(str_replace(' ', '', $values[4])) == 0 ? '' : $values[4]),
                            'position' => $values[5],
                            'birthDate' => $values[6],
                            'gender' => $values[7],
                            'language' => $values[8],
                            'schools' => $values[9],
                            'skills' => $values[10],
                            'createdDate' => date('Y-m-d H:j:s', time()),
                            'full_name' => $fullname,
                            'pwd' => HashPassword($pwd),
                            'user_level' => 3,
                            'office_id' => $oid,
                            'office_nametag' => $ont,
                            'approved' => 0,
                            'user_type' => 'office',
                            'activeState' => 0,
                            'banned' => 0,
                            'activation_code' => $key,
                            'cryptedText' => $encrypted
                        );

                        //check if user exist
                        $sql = "SELECT u_id FROM user_u WHERE office_id = " . MySQL::filter($_SESSION['office_id']) . " AND office_nametag = '" . MySQL::filter($_SESSION['office_nametag']) . "' AND full_name = '" . MySQL::filter($fullname) . "' AND user_email = '" . MySQL::filter($values[3]) . "'";

                        $rr = MySQL::query($sql, false, false);

                        if (empty($rr)) { //doesen't exist
                            $res = MySQL::insertIgnore('user_u', $array_of_values);

                            if (is_numeric($res)) {
                                //@todo actionlogger
                                User::globalSkillUserAdd($array_of_values['user_email'],$_SESSION['database']);
                                //user array for sending email
                                $newUserArray[] = array('name' => $fullname, 'email' => $values[3], 'password' => $pwd, 'encrypted'=>$encrypted);
                                $array_of_values['id'] = $res;
                                $returnUserArray[] = $array_of_values;
                                //group array
                                if (strlen(str_replace(' ', '', $values[4])) !== 0)
                                    $newGroupArray[$values[4]][] = $res;
                            }
                        } else {
                            $message[] = $fullname; //array('name'=>$fullname,'message'=>'Existing user');
                        }
                        //);
                        //$result[] = $values;
                        $values = array();
                    }
                }
                //delete uploaded file
                unlink($file);

                if (!empty($returnUserArray)) {

                    //save new userGroups
                    if (!empty($newGroupArray)) {
                        $values = array_keys($newGroupArray);
                        foreach ($values as $k => $v) {
                            $doname = normalize_special_characters(str_replace(' ', '', strtolower($v)));
                            $array_of_values1 = array(
                                'name' => $v,
                                'doname' => $doname,
                                'office_id' => $oid,
                                'office_nametag' => $ont,
                                //'createdDate'=>date('Y-m-d H:j:s', time()),
                                'owner' => $ow
                            );
                            //mégegyszer ua groupot nem hozom létre
                            //akkor lekerdezem az ID-jét, hogy mar letezik-e
                            $tres = MySQL::query("SELECT usergroup_id FROM user_usergroup WHERE doname ='" . $doname . "' AND office_id = " . MySQL::filter($oid) . " AND office_nametag = '" . MySQL::filter($ont) . "'", false, false);
                            if (!empty($tres))
                                $usergroup_id = $tres[0]['usergroup_id'];
                            else {
                                $res = MySQL::insertIgnore('user_usergroup', $array_of_values1);
                                $usergroup_id = $res;
                                $returnGroupArray[] = $v;
                            }


                            //save users to usergroup table too
                            foreach ($newGroupArray[$v] as $row) {
                                $array_of_values2 = array(
                                    'usergroup_id' => $usergroup_id,
                                    'u_id' => $row,
                                    'office_id' => $formArray['office_id'],
                                    'office_nametag' => $formArray['office_nametag'],
                                    //'createdDate'=>date('Y-m-d H:j:s', time()),
                                    'owner' => $ow
                                );
                                $res2 = MySQL::insertIgnore('user_usergroupUsers', $array_of_values2);
                            }
                        }
                    }

                    $usersArray = array();
                    foreach ($returnUserArray as &$row)
                        $usersArray[] = array(
                            'id' => $row['id'],
                            'pre' => $row['elotag'],
                            'forname' => $row['keresztnev'],
                            'surname' => $row['vezeteknev'],
                            'fullname' => $row['full_name'],
                            'department' => $row['department'],
                            'registered' => date('Y.m.d', strtotime($row['createdDate'])),
                            'skills' => $row['skills'],
                            'img' => '',
                            'email' => $row['user_email'],
                            'gender' => $row['gender'],
                            'birth' => $row['birthDate'],
                            'languages' => $row['language'],
                            'schools' => $row['schools'],
                            'active' => 'inactive'
                        );

                    $returnArray['result'] = $usersArray;
                    $returnArray['message'] = 'Users created successfully';

                    //send email to new users
                    foreach ($newUserArray as $user)
                        SkillMailer::sendRegisteredEmail($user, $registrar, $user['encrypted']);

                    $returnData = $returnArray; //array('success', 'message' => 'Minden ok');

                } else {
                    if (is_array($message) && !empty($message))
                        $returnData = array('type' => 'error', 'message' => 'The following user exist: ' . implode(', ', $message));
                    else
                        $returnData = array('type' => 'error', 'message' => 'No data presented');
                }

            } else {
                $returnData = array('type' => 'error', 'message' => 'No header presented');
            }
        } else {
            $returnData = array('type' => 'error', 'message' => 'sikertelen feltöltés');
        }
    } else {
        $returnData = array('type' => 'error', 'message' => 'The file is empty');
    }
} else {
    $returnData = array('type' => 'error', 'message' => 'Misspelled data sent to server');
}

$_SESSION['LAST_ACTIVITY'] = time();
printSortResult($returnData);
?>